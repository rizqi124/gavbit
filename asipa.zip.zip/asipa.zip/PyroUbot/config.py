import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "999"))

DEVS = list(map(int, os.getenv("DEVS", "1300290237").split()))

API_ID = int(os.getenv("API_ID", "27870788"))

API_HASH = os.getenv("API_HASH", "670ae2d80b739892fc2ebb569fae15c8")

BOT_TOKEN = os.getenv("BOT_TOKEN", "8570586625:AAHHpuQq1da00QgQTWauBj0HMxQuAyBcUAA")

OWNER_ID = int(os.getenv("OWNER_ID", "7250971800"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002886184276").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://spalaman838_db_user:He7Il2qOFQSFDTSr@cluster0.a7hwruw.mongodb.net/?appName=Cluster0")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002671518601"))
