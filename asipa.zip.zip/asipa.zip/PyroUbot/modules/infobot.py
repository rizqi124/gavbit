import asyncio
from pyrogram import Client, filters

# Informasi modul
__MODULE__ = "info bot"
__HELP__ = """
<b>Bolt Xtreme 

⎆ ᴀᴅᴀʟᴀʜ ᴜsᴇʀ ʙᴏᴛ xᴛʀᴇᴍᴇ ʏᴀɴɢ ᴅɪɢᴜɴᴀᴋᴀɴ ᴜɴᴛᴜᴋ ᴍᴇᴍᴜᴅᴀʜᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀ ᴅᴀʟᴀᴍ ᴘᴇᴋᴇʀᴊᴀᴀɴ ᴍᴇʀᴇᴋᴀ sᴇᴘᴇʀᴛɪ ʙʀᴏᴀᴅᴄᴀsᴛ ᴏᴛᴏᴍᴀᴛɪs ᴋᴇ sᴇᴍᴜᴀ ɢʀᴜᴘ , ᴄᴏɴᴠᴇʀᴛ ɢᴀᴍʙᴀʀ ᴍᴇɴᴊᴀᴅɪ ʟɪɴᴋ , sᴇʀᴛᴀ ʙᴀɴʏᴀᴋ ʟᴀɢɪ ᴋᴇɢᴜɴᴀᴀɴ ɴʏᴀ
"""
